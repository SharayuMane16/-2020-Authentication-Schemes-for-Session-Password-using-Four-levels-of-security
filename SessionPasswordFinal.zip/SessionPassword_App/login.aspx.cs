﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Net.Mail;
namespace DataSecurityRSA
{
    public partial class login : System.Web.UI.Page
    {
        private static string imgPassword1 = string.Empty;
        private static string imgPassword2 = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                imgPassword1 = string.Empty;
                imgPassword2 = string.Empty;
                fillImages();
            }
        }
        private void fillImages()
        {
            using (SqlDataAdapter da = new SqlDataAdapter(new SqlCommand("select imgId, name, imgPath, imgChar, imgSetType from ImageMaster where imgSetType=1 order by NEWID();select imgId, name, imgPath, imgChar, imgSetType from ImageMaster where imgSetType=2 order by NEWID()", DbHelper.conn)))
            {
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    ImageButton1.ImageUrl = ds.Tables[0].Rows[0]["imgPath"].ToString();
                    ImageButton2.ImageUrl = ds.Tables[0].Rows[1]["imgPath"].ToString();
                    ImageButton3.ImageUrl = ds.Tables[0].Rows[2]["imgPath"].ToString();
                    ImageButton4.ImageUrl = ds.Tables[0].Rows[3]["imgPath"].ToString();
                    ImageButton5.ImageUrl = ds.Tables[0].Rows[4]["imgPath"].ToString();
                    ImageButton6.ImageUrl = ds.Tables[0].Rows[5]["imgPath"].ToString();
                    ImageButton7.ImageUrl = ds.Tables[0].Rows[6]["imgPath"].ToString();
                    ImageButton8.ImageUrl = ds.Tables[0].Rows[7]["imgPath"].ToString();
                    ImageButton9.ImageUrl = ds.Tables[0].Rows[8]["imgPath"].ToString();
                    HiddenField1.Value = ds.Tables[0].Rows[0]["imgChar"].ToString();
                    HiddenField2.Value = ds.Tables[0].Rows[1]["imgChar"].ToString();
                    HiddenField3.Value = ds.Tables[0].Rows[2]["imgChar"].ToString();
                    HiddenField4.Value = ds.Tables[0].Rows[3]["imgChar"].ToString();
                    HiddenField5.Value = ds.Tables[0].Rows[4]["imgChar"].ToString();
                    HiddenField6.Value = ds.Tables[0].Rows[5]["imgChar"].ToString();
                    HiddenField7.Value = ds.Tables[0].Rows[6]["imgChar"].ToString();
                    HiddenField8.Value = ds.Tables[0].Rows[7]["imgChar"].ToString();
                    HiddenField9.Value = ds.Tables[0].Rows[8]["imgChar"].ToString();
                }
                if (ds.Tables[1].Rows.Count > 0)
                {
                    ImageButton10.ImageUrl = ds.Tables[1].Rows[0]["imgPath"].ToString();
                    ImageButton11.ImageUrl = ds.Tables[1].Rows[1]["imgPath"].ToString();
                    ImageButton12.ImageUrl = ds.Tables[1].Rows[2]["imgPath"].ToString();
                    ImageButton13.ImageUrl = ds.Tables[1].Rows[3]["imgPath"].ToString();
                    ImageButton14.ImageUrl = ds.Tables[1].Rows[4]["imgPath"].ToString();
                    ImageButton15.ImageUrl = ds.Tables[1].Rows[5]["imgPath"].ToString();
                    ImageButton16.ImageUrl = ds.Tables[1].Rows[6]["imgPath"].ToString();
                    ImageButton17.ImageUrl = ds.Tables[1].Rows[7]["imgPath"].ToString();
                    ImageButton18.ImageUrl = ds.Tables[1].Rows[8]["imgPath"].ToString();
                    HiddenField10.Value = ds.Tables[1].Rows[0]["imgChar"].ToString();
                    HiddenField11.Value = ds.Tables[1].Rows[1]["imgChar"].ToString();
                    HiddenField12.Value = ds.Tables[1].Rows[2]["imgChar"].ToString();
                    HiddenField13.Value = ds.Tables[1].Rows[3]["imgChar"].ToString();
                    HiddenField14.Value = ds.Tables[1].Rows[4]["imgChar"].ToString();
                    HiddenField15.Value = ds.Tables[1].Rows[5]["imgChar"].ToString();
                    HiddenField16.Value = ds.Tables[1].Rows[6]["imgChar"].ToString();
                    HiddenField17.Value = ds.Tables[1].Rows[7]["imgChar"].ToString();
                    HiddenField18.Value = ds.Tables[1].Rows[8]["imgChar"].ToString();

                }
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string result = txtCaptcha.Text;
            if (result == Session["CaptchaValue"].ToString())
            {
                cptCaptcha.ValidateCaptcha(txtCaptcha2.Text.Trim());
                if (cptCaptcha.UserValidated)
                {
                    if (Session["otp"].ToString() == txtOtp.Text)
                    {

                        using (SqlDataAdapter da = new SqlDataAdapter(new SqlCommand("select userId, username, name, email from UserMaster where username=@u and password=@p and imgPassword=@pass", DbHelper.conn)))
                        {
                            da.SelectCommand.Parameters.AddWithValue("@u", txtUsername.Text.Trim());
                            da.SelectCommand.Parameters.AddWithValue("@p", txtPassword.Text.Trim());
                            da.SelectCommand.Parameters.AddWithValue("@pass", imgPassword1 + imgPassword2);
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            if (dt.Rows.Count > 0)
                            {
                                Session["userid"] = dt.Rows[0]["userId"].ToString();
                                Session["name"] = dt.Rows[0]["name"].ToString();
                                Session["email"] = dt.Rows[0]["email"].ToString();
                                Response.Redirect("index.aspx");
                            }
                            else
                            {
                                txtUsername.Text = txtPassword.Text = imgPassword1 = imgPassword2 = string.Empty;
                                // lblMsg.Text = "Invalid username and password or invalid image sequence";
                                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('Invalid username and password');window.location='login.aspx';", true);
                            }
                        }
                    }
                    else
                    {
                        txtUsername.Text = txtPassword.Text = imgPassword1 = imgPassword2 = string.Empty;
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('Invalid OTP');window.location='login.aspx';", true);
                    }
                }
                else
                {
                    txtCaptcha2.Text = "";
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", "alert('Invalid Character captcha')", true);
                }
            }
            else
            {
                txtCaptcha.Text = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", "alert('Invalid Mathamatical captcha')", true);
            }

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword1.Length < 4)
            {
                imgPassword1 += HiddenField1.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part1')", true);
            }
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword1.Length < 4)
            {
                imgPassword1 += HiddenField2.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part1')", true);
            }
        }

        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword1.Length < 4)
            {
                imgPassword1 += HiddenField3.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part1')", true);
            }
        }

        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword1.Length < 4)
            {
                imgPassword1 += HiddenField4.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part1')", true);
            }
        }

        protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword1.Length < 4)
            {
                imgPassword1 += HiddenField5.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part1')", true);
            }
        }

        protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword1.Length < 4)
            {
                imgPassword1 += HiddenField6.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part1')", true);
            }
        }

        protected void ImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword1.Length < 4)
            {
                imgPassword1 += HiddenField7.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part1')", true);
            }
        }

        protected void ImageButton8_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword1.Length < 4)
            {
                imgPassword1 += HiddenField8.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part1')", true);
            }
        }

        protected void ImageButton9_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword1.Length < 4)
            {
                imgPassword1 += HiddenField9.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part1')", true);
            }
        }

        protected void ImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword2.Length < 4)
            {
                imgPassword2 += HiddenField10.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part2')", true);
            }
        }

        protected void ImageButton11_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword2.Length < 4)
            {
                imgPassword2 += HiddenField11.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part2')", true);
            }
        }

        protected void ImageButton12_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword2.Length < 4)
            {
                imgPassword2 += HiddenField12.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part2')", true);
            }
        }

        protected void ImageButton13_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword2.Length < 4)
            {
                imgPassword2 += HiddenField13.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part2')", true);
            }
        }

        protected void ImageButton14_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword2.Length < 4)
            {
                imgPassword2 += HiddenField14.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part2')", true);
            }
        }

        protected void ImageButton15_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword2.Length < 4)
            {
                imgPassword2 += HiddenField15.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part2')", true);
            }
        }

        protected void ImageButton16_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword2.Length < 4)
            {
                imgPassword2 += HiddenField16.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part2')", true);
            }
        }

        protected void ImageButton17_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword2.Length < 4)
            {
                imgPassword2 += HiddenField17.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part2')", true);
            }
        }

        protected void ImageButton18_Click(object sender, ImageClickEventArgs e)
        {
            if (imgPassword2.Length < 4)
            {
                imgPassword2 += HiddenField18.Value;
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('You can select maximum 4 images in part2')", true);
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            imgPassword1 = string.Empty;
            imgPassword2 = string.Empty;
            fillImages();
        }

        [System.Web.Services.WebMethod]

        public static string SendOtp(string username)
        {
            using (SqlDataAdapter da = new SqlDataAdapter(new SqlCommand("select userId, email from UserMaster where username=@u", DbHelper.conn)))
            {
                da.SelectCommand.Parameters.AddWithValue("@u", username.Trim());

                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {

                    string otp = GenerateRandomNo();

                    try
                    {
                        SmtpClient SmtpServer = new SmtpClient();
                        MailMessage mail = new MailMessage();
                        SmtpServer.Credentials = new System.Net.NetworkCredential("driemsproject@gmail.com",
                            "driemsproject123");
                        SmtpServer.Port = 587;
                        SmtpServer.EnableSsl = true;
                        SmtpServer.Host = "smtp.gmail.com";
                        mail = new MailMessage();
                        mail.From = new MailAddress("driemsproject@gmail.com");

                        mail.To.Add(dt.Rows[0]["email"].ToString());
                        mail.Subject = "Session OTP";
                        mail.Body = "Hi " + username + ". Your Login OTP Is " + otp;
                        SmtpServer.Send(mail);
                    }
                    catch (Exception ex)
                    {
                        return ex.Message;

                    }
                    return "Opt Send successfully Please check your Email Id";
                }
                else
                {
                    return "Invalid Username";
                }

            }
        }
        public static string GenerateRandomNo()
        {
            Random _random = new Random();
            string otp = _random.Next(0, 9999).ToString("D4");
            //Session["otp"] = otp;
            HttpContext.Current.Session["otp"] = otp;
            return otp;
        }

    }
}