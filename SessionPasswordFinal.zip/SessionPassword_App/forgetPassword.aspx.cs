﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Net.Mail;
namespace DataSecurityRSA
{
    public partial class ForgetPassword : System.Web.UI.Page
    {
        string ImgSeq = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnForget_Click(object sender, EventArgs e)
        {
            using (SqlDataAdapter da = new SqlDataAdapter(new SqlCommand("select userId, username, password, name, email, contact, address, imgPassword from UserMaster where username=@username", DbHelper.conn)))
            {
                da.SelectCommand.Parameters.AddWithValue("@username", txtUsername.Text);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    string pass = dt.Rows[0]["imgPassword"].ToString();
                    char[] c = pass.ToCharArray();
                    for (int i = 0; i < c.Length; i++)
                    {
                        using (SqlDataAdapter daGet = new SqlDataAdapter(new SqlCommand("select imgId, name, imgPath, imgChar, imgSetType from ImageMaster where imgChar=@imgChar", DbHelper.conn)))
                        {
                            daGet.SelectCommand.Parameters.AddWithValue("@imgChar", c[i]);
                            DataTable dtget = new DataTable();
                            daGet.Fill(dtget);
                            if (dtget.Rows.Count > 0)
                            {
                                ImgSeq += dtget.Rows[0]["name"].ToString() + ",";
                            }
                        }
                    }
                    ImgSeq = ImgSeq.Remove(ImgSeq.Length - 1, 1);

                    try
                    {
                        MailMessage mail = new MailMessage();
                        SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

                        mail.From = new MailAddress("driemsproject@gmail.com");
                        mail.To.Add(dt.Rows[0]["email"].ToString());
                        mail.Subject = "Password Recovery";
                        mail.Body = "Hi " + dt.Rows[0]["username"].ToString() + " your Text Password= " + dt.Rows[0]["password"].ToString() + " and Your Image sequesnce is " + ImgSeq + " .";
                        SmtpServer.Port = 587;
                        SmtpServer.Credentials = new System.Net.NetworkCredential("driemsproject@gmail.com", "driemsproject123");
                        SmtpServer.EnableSsl = true;

                        SmtpServer.Send(mail);
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", "alert('Your password send on your email id successfully')", true);
                    }
                    catch (Exception ex)
                    {
                        // MessageBox.Show(ex.ToString());
                    }
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", "alert('Invalid username')", true);
                }
            }
        }
    }
}