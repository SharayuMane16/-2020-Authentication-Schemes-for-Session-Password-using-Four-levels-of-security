﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace DataSecurityRSA
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //fillGridview();
                //fillGridViewSharewithMe();
            }
        }

        private void fillGridview()
        {
            using (SqlDataAdapter da = new SqlDataAdapter(new SqlCommand("select dataId, userId, name, dataPath, dataExt, dataKey, uploadDate from DataMaster where userId=@userId", DbHelper.conn)))
            {
                da.SelectCommand.Parameters.AddWithValue("@userId", Session["userid"].ToString());
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
        }

        private void fillGridViewSharewithMe()
        {
            using (SqlDataAdapter da = new SqlDataAdapter(new SqlCommand("select s.shareId, s.fromuserId, s.touserId, s.dataId,d.name,d.dataKey,u.username, s.shareDate from ShareMaster s join UserMaster u on(s.fromuserId=u.userId) join DataMaster d on(s.dataId=d.dataId) where touserId=@userId", DbHelper.conn)))
            {
                da.SelectCommand.Parameters.AddWithValue("@userId", Session["userid"].ToString());
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    GridView2.DataSource = dt;
                    GridView2.DataBind();
                }
            }
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "delete")
            {
                using (SqlCommand cmd = new SqlCommand("delete from DataMaster where dataId=@dataId",DbHelper.conn))
                {
                    cmd.Parameters.AddWithValue("@dataId", e.CommandArgument);
                    DbHelper.conn.Open();
                    cmd.ExecuteNonQuery();
                    DbHelper.conn.Close();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('Delete successfully');window.location='index.aspx';", true);
                }
            }
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "delete")
            {
                using (SqlCommand cmd = new SqlCommand("delete from ShareMaster where shareId=@shareId", DbHelper.conn))
                {
                    cmd.Parameters.AddWithValue("@shareId", e.CommandArgument);
                    DbHelper.conn.Open();
                    cmd.ExecuteNonQuery();
                    DbHelper.conn.Close();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('Delete successfully');window.location='index.aspx';", true);
                }
            }
        }

        protected void GridView2_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }
    }
}